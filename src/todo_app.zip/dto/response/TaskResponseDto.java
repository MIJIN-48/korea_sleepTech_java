package todo_app.dto.response;

import java.util.Date;

public class TaskResponseDto {
	private Long id;
	private String todoDate;
	private String content;
	private boolean todoCheck;
	private Date updateDate;
}
