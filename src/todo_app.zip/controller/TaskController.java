package todo_app.controller;

import todo_app.dto.request.TaskRequestDto;
import todo_app.service.TaskServiceImpl;
import todo_app.service.UserServiceImpl;

public class TaskController {
	private TaskServiceImpl taskServiceImpl;
	private UserServiceImpl userServiceImpl;
	
	public TaskController() {
		this.userServiceImpl = new UserServiceImpl();
		this.taskServiceImpl = new TaskServiceImpl(userServiceImpl);
	}
	
	public void createTask(TaskRequestDto dto) {
		taskServiceImpl.createTask(dto);
	}
}
