package todo_app.service;

import todo_app.dto.request.TaskRequestDto;

public interface TaskService {
	void createTask(TaskRequestDto dto);
}
