package todo_app.service;

import todo_app.dto.request.TaskRequestDto;
import todo_app.entity.Task;
import todo_app.repository.TaskRepository;

public class TaskServiceImpl implements TaskService {
	private final TaskRepository repository;
	private final UserServiceImpl userServiceImpl;
	private static long taskSequenceId = 1;
	
	public TaskServiceImpl(UserServiceImpl userServiceImpl) {
		this.repository = TaskRepository.getInstance();
		this.userServiceImpl = userServiceImpl;
	}
	
	private Long generatedTaskId() {
		return taskSequenceId++;
	}
	
	@Override
	public void createTask(TaskRequestDto dto) {
		Long userId = userServiceImpl.getUserSequenceId();
		Task newTask = new Task(generatedTaskId(), userId
				, dto.getContent(), dto.getTodoDate(), dto.isTodoCheck());
		repository.save(newTask);
	}
	
	

}
